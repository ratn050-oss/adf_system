<?php
return 'narayana-hotel';

// Available businesses:
// - 'bens-cafe'
// - 'eat-meet'
// - 'furniture-jepara'
// - 'karimunjawa-party-boat'
// - 'narayana-hotel'
// - 'pabrik-kapal'
